/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jrblanco.prog05_tarea.PROG05_Ejerc1;

import com.jrblanco.prog05_tarea.PROG05_Ejerc1_util.Dni;
import com.jrblanco.prog05_tarea.PROG05_Ejerc1_util.Validar;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase principal de programa
 * 
 * @author Jose Ramón Blanco Gutiérrez
 */
public class Principal {
    
    
    /**
     * Metodo que muestra en pantalla el menú
     */
    public static void menu() {
        System.err.println();
        System.out.println("------------------------------");
        System.out.println("    Gestión de un Vehiculo    ");
        System.out.println("------------------------------");
        System.out.println("1. Nuevo Vehiculo");
        System.out.println("2. Ver Matrícula");
        System.out.println("3. Ver Número de Kilómetros");
        System.out.println("4. Actualizar Kilómetros");
        System.out.println("5. Ver años de antigüedad");
        System.out.println("6. Mostrar propietario");
        System.out.println("7. Mostrar descripción");
        System.out.println("8. Mostrar Precio");
        System.out.println("9. Salir");
        System.out.println("------------------------------");
        System.out.println("Seleccione una opción [1,2,3,4,5,6,7,8,9]");
        
    }
    
    /**
     * Método que crea el Nuevo Vehiculo.
     * 
     * @return Retorna el objeto Vehiculo creado
     */
    public static Vehiculo nuevoVehiculo(){
        Scanner sc = new Scanner(System.in);
        /**
         * Variables temporales para almacenar los datos del vehiculo antes de instanciar el objeto.
         */
        String marca;
        String matricula;
        int kilometros = 0;
        int dia, mes, anyo;
        LocalDate fecha;
        String descripcion;
        float precio;
        String nombre;
        String dniString;
        Dni dni;
        
        boolean check; //Variable booleana utilizanada en los procesos de verificar el dato
        
        System.out.println("Introduce marca del vehiculo:");
        marca = sc.nextLine();
        
        System.out.println("Introduce matricula del vehiculo:");
        matricula = sc.nextLine();
        
        do {
            System.out.println("Introduce los kilometros que tiene el vehiculo");
            kilometros = sc.nextInt();
            sc.nextLine();
            
            check = Validar.checkKilometros(kilometros); //Método de la clase Util que valida si el número de kilometros es mayor que 0
            
            if (!check) {
                System.out.println("ERROR KM: los Km del vehiculos tiene que ser mayor que 0");
            }
        }while(!check); //Repite hasta que se introduzca un kilometro mayor que 0
        
        do {
            System.out.println("----- Fecha de Matriculación -----");
            System.out.println("Introduce el día:");
            dia = sc.nextInt();
            sc.nextLine();
            
            System.out.println("Introduce el mes:");
            mes = sc.nextInt();
            sc.nextLine();
            
            System.out.println("Introduce el año:");
            anyo = sc.nextInt();
            sc.nextLine();

            fecha = LocalDate.of(anyo, mes, dia); //Inicia el Objeto con los datos creados
            
            check = Validar.checkFecha(fecha);   //Método de la clase Util que valida si la fecha es anterior a la fecha actual
            
            if (!check) {
                System.out.println("ERROR FECHA: La fecha debe ser anterior a hoy");
            }
        
        }while(!check); //Se repite mientras la fecha no sea anterior
        
        System.out.println("Introducir descripción del vehiculo:");
        descripcion = sc.nextLine();
        
        System.out.println("Introdicir precio del vehiculo:");
        precio = sc.nextFloat();
        sc.nextLine();
        
        System.out.println("Introducir nombre del propietario del vehiculo:");
        nombre = sc.nextLine();
        
        do {
            System.out.println("Introducir DNI con su Letra del propietario del vehiculo [00000000T]:");
            dniString = sc.nextLine();
            dni = new Dni();

            try {                          //Control de la excepción que genera si el DNI es incorrecto
                dni.setDni(dniString);
                check = true;
            } catch (Exception ex) {
                System.out.println(ex.getMessage()); //Muestra mensaje de la excepción diciendo que es Invalido
                check = false;
                //Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }while(!check);
        
        //Retorna el Objeto creado con los datos del vehiculo.
        return new Vehiculo(marca, matricula, kilometros, fecha, descripcion, precio, nombre, dni);
    }
    
    
    /**
     * Método main, donde esta el bucle principal del programa.
     * 
     * @param args 
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salir = false;
        byte opcion;
        Vehiculo vehiculo = null; // Iniciamos a null
        
        do {
            menu();
            opcion = sc.nextByte();
            
            switch (opcion){
                case 1: //1. Nuevo vehiculo
                    vehiculo = nuevoVehiculo();
                    System.out.println("Nuevo Vehiculo creado");
                    break;
                case 2: //2. Ver Matrícula
                    if (vehiculo != null) {
                        System.out.println("Matricula: " + vehiculo.getMatricula());
                    }else {
                        System.out.println("Se tiene que crear un nuevo Vehiculo [Opción 1]");
                    }
                    break;

                case 3: //3. Ver Número de Kilómetros
                    if (vehiculo != null) {
                        System.out.println("Kilometros: "+ vehiculo.getKilometros());
                    }else {
                        System.out.println("Se tiene que crear un nuevo Vehiculo [Opción 1]");
                    }
                    break;
                case 4: //4. Actualizar Kilómetros
                    if (vehiculo != null) {
                        System.out.println("Introduce los nuevos kilometos del vehículo:");
                        int numtemp = sc.nextInt();
                        sc.nextLine();
                        if (numtemp>vehiculo.getKilometros()) {   //Comprueba que los kilometros que se quieren actualizar es superior a los que ya existen
                            vehiculo.setKilometros(numtemp);
                        } else {
                            System.out.println("No puede tener menos kilometros");
                        }
                    }else {
                        System.out.println("Se tiene que crear un nuevo Vehiculo [Opción 1]");
                    }
                    break;
                case 5: //Ver años de antiguedad
                    if (vehiculo != null) {
                        System.out.println("El vehiculo tiene " + vehiculo.getAnios() + " años");
                    }else {
                         System.out.println("Se tiene que crear un nuevo Vehiculo [Opción 1]");
                    }
                    
                    break;
                case 6: //6. Mostrar Propietario
                    if (vehiculo != null) {
                        System.out.println("Propietario " + vehiculo.getNombrePropietaro());
                        System.out.println("con DNI: " + vehiculo.getDniPropietario());
                    }else {
                        System.out.println("Se tiene que crear un nuevo Vehiculo [Opción 1]");
                    }
                    break;
                case 7: //7. Mostrar descripción
                    if (vehiculo != null) {
                        System.out.println("Descripcion: " + vehiculo.getDescripcion());
                        System.out.println("Matricula: " + vehiculo.getMatricula());
                        System.out.println("Kilometros: " + vehiculo.getKilometros());
                    }else {
                        System.out.println("Se tiene que crear un nuevo Vehiculo [Opción 1]");
                    }
                    break;
                case 8: //8. Mostrar precio
                    if (vehiculo != null) {
                        System.out.printf("El precio es: %.2f €\n",vehiculo.getPrecio());
                        
                    }else {
                        System.out.println("Se tiene que crear un nuevo Vehiculo [Opción 1]");
                    }
                    break;
                case 9: //9. Salir
                    salir=true;
                    break;
            }
          
        }while (!salir); //repite mientras salir sea false  
    } 
}
