
package prog08_1_tarea;

/**
 * Interface Imprimible
 * 
 * @author JRBlanco
 */
public interface Imprimible {

    /**
     * Método que devolvera la información en forma de cadena de texto
     * @return Cadena de texto
     */
    public String devolverInfoString();
}