/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jrblanco.dni;

/**
 *
 * @author JRBlanco
 */
public class Dni {
    private int numDni;

    
    
    /**
     * Métodos
     */
    public int getDni() {
        return numDni;
    }

    public String getNIF() {
        return (""+this.numDni+Dni.calcularLetraNIF(numDni));
    }
    
    public void setDni(String numNIF) throws Exception {
        
        if (Dni.validarNIF(numNIF)) {
            this.numDni = Dni.extraerNumeroNIF(numNIF);
        } else {
            throw new Exception ("NIF Invalido: " + numNIF);
        }
        
    }
    
  
    public void setDni(int dni) throws Exception {
        
        if (dni>999999 && dni<99999999) {
           this.numDni = dni; 
        } else {
            throw new Exception ("DNI invalido: "+ String.valueOf(dni));
        }
        
    }    
    
    public static char calcularLetraNIF(int dni){
        String secuenciaLetrasNIF = "TRWAGMYFPDXBNJZSQVHLCKE";
        return secuenciaLetrasNIF.charAt(dni % 23);
    }
    
    public static boolean validarNIF(String NIF) {
        int numero;
        char letra;
        boolean valido = false;
        
        numero = Dni.extraerNumeroNIF(NIF);
        letra = Dni.extraerLetraNIF(NIF.toUpperCase());
        
        if (letra == Dni.calcularLetraNIF(numero)) {
            valido = true;
        }
        return valido;
    }
    
    public static char extraerLetraNIF(String NIF) {
        char letra = NIF.charAt(NIF.length()-1);
        return letra;
    }
    
    public static int extraerNumeroNIF(String NIF) {
        return Integer.parseInt(NIF.substring(0, NIF.length()-1));
    }
    
    
    
}
