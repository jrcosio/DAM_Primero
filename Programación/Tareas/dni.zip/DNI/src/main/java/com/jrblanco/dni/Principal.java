/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jrblanco.dni;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author JRBlanco
 */
public class Principal {
    public static void main(String[] args) {
        
        Dni dni = new Dni();
        
        try {
            dni.setDni(72033688);
        } catch (Exception ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println("DNI: " + dni.getDni());
        System.out.println("NIF: " + dni.getNIF());

        
    }
    
}
